"use client";

import { useMemo, useState } from "react";

type Item = { id: number; name: string; qty: number; price: number };

export default function ReceiptBuilder() {
  const [business, setBusiness] = useState("Your Business");
  const [customer, setCustomer] = useState("");
  const [tax, setTax] = useState(0);
  const [discount, setDiscount] = useState(0);
  const [items, setItems] = useState<Item[]>([
    { id: 1, name: "Example product", qty: 1, price: 10 },
  ]);

  const subtotal = useMemo(
    () => items.reduce((sum, item) => sum + item.qty * item.price, 0),
    [items]
  );
  const total = Math.max(0, subtotal - discount + tax);

  function updateItem(id: number, patch: Partial<Item>) {
    setItems((current) => current.map((item) => item.id === id ? { ...item, ...patch } : item));
  }

  function addItem() {
    setItems((current) => [
      ...current,
      { id: Date.now(), name: "New product", qty: 1, price: 0 },
    ]);
  }

  function removeItem(id: number) {
    setItems((current) => current.filter((item) => item.id !== id));
  }

  return (
    <div className="grid gap-8 lg:grid-cols-2">
      <section className="rounded-2xl border border-slate-200 bg-white p-6">
        <h2 className="text-xl font-semibold">Receipt details</h2>

        <div className="mt-6 grid gap-4">
          <label className="text-sm font-medium">
            Business name
            <input value={business} onChange={(e) => setBusiness(e.target.value)}
              className="mt-2 w-full rounded-lg border border-slate-300 px-3 py-2.5" />
          </label>

          <label className="text-sm font-medium">
            Customer name
            <input value={customer} onChange={(e) => setCustomer(e.target.value)}
              className="mt-2 w-full rounded-lg border border-slate-300 px-3 py-2.5" />
          </label>

          <div>
            <div className="mb-3 flex items-center justify-between">
              <h3 className="font-semibold">Products</h3>
              <button onClick={addItem} className="rounded-lg border px-3 py-1.5 text-sm font-medium">
                + Add product
              </button>
            </div>

            <div className="space-y-3">
              {items.map((item) => (
                <div key={item.id} className="grid grid-cols-[1fr_70px_90px_auto] gap-2">
                  <input value={item.name} onChange={(e) => updateItem(item.id, { name: e.target.value })}
                    className="rounded-lg border border-slate-300 px-2 py-2" />
                  <input type="number" min="1" value={item.qty}
                    onChange={(e) => updateItem(item.id, { qty: Number(e.target.value) })}
                    className="rounded-lg border border-slate-300 px-2 py-2" />
                  <input type="number" min="0" step="0.01" value={item.price}
                    onChange={(e) => updateItem(item.id, { price: Number(e.target.value) })}
                    className="rounded-lg border border-slate-300 px-2 py-2" />
                  <button onClick={() => removeItem(item.id)} className="px-2 text-sm text-red-600">Remove</button>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <label className="text-sm font-medium">
              Discount
              <input type="number" min="0" step="0.01" value={discount}
                onChange={(e) => setDiscount(Number(e.target.value))}
                className="mt-2 w-full rounded-lg border border-slate-300 px-3 py-2.5" />
            </label>
            <label className="text-sm font-medium">
              Tax
              <input type="number" min="0" step="0.01" value={tax}
                onChange={(e) => setTax(Number(e.target.value))}
                className="mt-2 w-full rounded-lg border border-slate-300 px-3 py-2.5" />
            </label>
          </div>
        </div>
      </section>

      <section className="rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
        <div className="text-center">
          <h2 className="text-2xl font-bold">{business || "Your Business"}</h2>
          <p className="mt-1 text-sm text-slate-500">RECEIPT</p>
          {customer && <p className="mt-4 text-sm">Customer: {customer}</p>}
        </div>

        <div className="mt-8 space-y-3">
          {items.map((item) => (
            <div key={item.id} className="flex justify-between border-b pb-3">
              <div>
                <p className="font-medium">{item.name}</p>
                <p className="text-sm text-slate-500">{item.qty} × ${item.price.toFixed(2)}</p>
              </div>
              <p className="font-medium">${(item.qty * item.price).toFixed(2)}</p>
            </div>
          ))}
        </div>

        <div className="mt-6 space-y-2 text-sm">
          <div className="flex justify-between"><span>Subtotal</span><span>${subtotal.toFixed(2)}</span></div>
          <div className="flex justify-between"><span>Discount</span><span>-${discount.toFixed(2)}</span></div>
          <div className="flex justify-between"><span>Tax</span><span>${tax.toFixed(2)}</span></div>
          <div className="mt-3 flex justify-between border-t pt-4 text-lg font-bold">
            <span>Total</span><span>${total.toFixed(2)}</span>
          </div>
        </div>

        <button onClick={() => window.print()}
          className="mt-8 w-full rounded-lg bg-slate-900 px-4 py-3 font-semibold text-white print:hidden">
          Print receipt
        </button>
      </section>
    </div>
  );
}
