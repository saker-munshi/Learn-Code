import ReceiptBuilder from "@/components/receipts/ReceiptBuilder";

export default function NewReceiptPage() {
  return (
    <main className="min-h-screen px-6 py-10">
      <div className="mx-auto max-w-7xl">
        <p className="text-sm text-slate-500">Receipt Builder</p>
        <h1 className="mt-1 text-3xl font-bold">Create a receipt</h1>
        <p className="mt-2 text-slate-600">Add products and see the receipt preview update instantly.</p>
        <div className="mt-8">
          <ReceiptBuilder />
        </div>
      </div>
    </main>
  );
}
