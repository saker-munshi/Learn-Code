import Link from "next/link";

export default function HomePage() {
  return (
    <main className="min-h-screen">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <div className="text-xl font-bold tracking-tight">ReceiptForge</div>
        <Link
          href="/login"
          className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-700"
        >
          Login
        </Link>
      </nav>

      <section className="mx-auto max-w-6xl px-6 pb-20 pt-16">
        <div className="max-w-3xl">
          <p className="mb-4 text-sm font-semibold uppercase tracking-wider text-slate-500">
            Custom receipt platform
          </p>
          <h1 className="text-5xl font-bold tracking-tight text-slate-950">
            Create professional receipts your way.
          </h1>
          <p className="mt-6 text-lg leading-8 text-slate-600">
            Build, customize, save, print, download, and securely share receipts for products or services.
          </p>
          <div className="mt-8 flex gap-3">
            <Link href="/login" className="rounded-lg bg-slate-900 px-5 py-3 font-semibold text-white">
              Get started
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}
