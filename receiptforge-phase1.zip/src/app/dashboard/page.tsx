import Link from "next/link";

export default function DashboardPage() {
  return (
    <main className="min-h-screen px-6 py-10">
      <div className="mx-auto max-w-6xl">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-slate-500">Dashboard</p>
            <h1 className="text-3xl font-bold">Your receipts</h1>
          </div>
          <Link href="/receipts/new" className="rounded-lg bg-slate-900 px-4 py-2.5 font-semibold text-white">
            + Create receipt
          </Link>
        </div>

        <div className="mt-8 grid gap-4 sm:grid-cols-3">
          {[
            ["Total receipts", "0"],
            ["This month", "0"],
            ["Saved templates", "0"],
          ].map(([label, value]) => (
            <div key={label} className="rounded-2xl border border-slate-200 bg-white p-5">
              <p className="text-sm text-slate-500">{label}</p>
              <p className="mt-2 text-3xl font-bold">{value}</p>
            </div>
          ))}
        </div>

        <div className="mt-8 rounded-2xl border border-slate-200 bg-white p-8">
          <h2 className="text-lg font-semibold">Recent receipts</h2>
          <p className="mt-2 text-slate-500">No receipts yet. Create your first receipt to get started.</p>
        </div>
      </div>
    </main>
  );
}
