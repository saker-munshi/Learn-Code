import LoginForm from "@/components/auth/LoginForm";

export default function LoginPage() {
  return (
    <main className="flex min-h-screen items-center justify-center px-6 py-12">
      <div className="w-full max-w-md">
        <div className="mb-8">
          <p className="text-sm font-semibold text-slate-500">ReceiptForge</p>
          <h1 className="mt-2 text-3xl font-bold">Welcome back</h1>
          <p className="mt-2 text-slate-600">Sign in to manage your receipts.</p>
        </div>
        <LoginForm />
      </div>
    </main>
  );
}
