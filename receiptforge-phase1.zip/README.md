# ReceiptForge

Phase 1 starter: Next.js + TypeScript + Tailwind + Prisma-ready project structure.

## Requirements
- Node.js 20+
- npm
- PostgreSQL (Phase 2)

## Run
```bash
npm install
npm run dev
```

Open http://localhost:3000
